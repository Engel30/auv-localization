import socket
import sys
from lib.utilities import *

if len(sys.argv)<3:
	print "Insert command and Dummy IP"
	sys.exit(0)

if sys.argv[2]=='0' or sys.argv[2]=='3' or sys.argv[2]=='4':
	#a="\0" * 10
	b=chr(int(sys.argv[2]))+'\0'
	lung=2
	[d,a]=createRequestMessage(1,1,b,lung)
elif sys.argv[2]=='1':
	lung=len(sys.argv[3])+1
	#a="\0" * (8+lung)
	b=chr(int(sys.argv[2])) 
	for i in range(0,len(sys.argv[3])):
		b=b+chr(int(sys.argv[3][i]))
	[d,a]=createRequestMessage(1,1,b,lung)
elif sys.argv[2]=='2':
	lung=len(sys.argv[4])+2
	#a="\0" * (8+lung)
	b=chr(int(sys.argv[2]))+ chr(len(sys.argv[4]))+sys.argv[4]
	[d,a] = createRequestMessage(4,ord(sys.argv[3]),b,lung)
elif sys.argv[2]=='5'  or sys.argv[2]=='6' :
	#a="\0" * 10
	b=chr(int(sys.argv[2]))+'\0'
	lung=2
	[d,a]=createRequestMessage(4,ord(sys.argv[3]),b,lung)


print ":".join("{:02x}".format(ord(c)) for c in a)

hostname, sld, tld, port = 'www', 'integralist', 'co.uk', 80
target = '{}.{}.{}'.format(hostname, sld, tld)

# create an ipv4 (AF_INET) socket object using the tcp protocol (SOCK_STREAM)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# connect the client
# client.connect((target, port))
client.connect((sys.argv[1],  11999))

# send some data (in this case a HTTP GET request)
client.send(a)

# receive the response data (4096 is recommended buffer size)
response = client.recv(4096)

print ":".join("{:02x}".format(ord(c)) for c in response)

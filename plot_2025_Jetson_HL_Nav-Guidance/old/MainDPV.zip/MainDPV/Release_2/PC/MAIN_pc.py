import threading, time, socket, sys, select, Queue, utm, pynmea2, datetime, os
import numpy as np
from lib.utilities import *
from lib.USBL import *
from lib.Message import *

debug=False
l=len([name for name in os.listdir('.') if os.path.isfile(name)])
tcp_enabled=True #variabile che indica arrivato il messaggio di start dal tablet
address= [];
trasponder_number=0
trasponder_address=[]
surface_queue = Queue.Queue()
#evologics=Usbl("192.168.1.139",9200)
evologics=Usbl("127.0.0.1",9200)
FIRST_POS=False #Finche' non e' arrivata la prima posizine GPS non faccio partire la ricerca degli scooter
map_queue = Queue.Queue()
deliv_queue = Queue.Queue()
x_utm=0
y_utm=0
zone_letter=""
zone_number=0
latitude=0
longitude=0
Localization=False #
Count=10;
TCPserverstate = stateMachine()######################
mb=unit() 
mb.typ=1
mb.address=1;
mb.vendor=0;
mb.model=0;
genericList=['\0','\1','\2','\3','\4','\5','\6']
genericListLength = 7
specificList= []
specificListLength = 0
mb2=unit()
mb2.typ=4;
mb2.vendor=0;
mb2.model=0;


def GPS_loop(): #loop che riceve su udp le stringhe GPS
	localIP     = "127.0.0.1"
	localPort   = 8881
	bufferSize  = 1024
	 
	# Create a datagram socket
	UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
	
	# Bind to address and ip
	UDPServerSocket.bind((localIP, localPort))
	print("UDP server up and listening")
	
	# Listen for incoming datagrams
	while(True):
	    bytesAddressPair = UDPServerSocket.recvfrom(bufferSize)
	    message = bytesAddressPair[0]
	    msg = pynmea2.parse(message)
	    if (msg.lat!="" and msg.lon!=""):
		    global FIRST_POS, latitude, longitude,x_utm,y_utm,zone_number,zone_letter,Count
		    latitude=float(msg.lat[:2])+float(msg.lat[2:])/60
		    longitude=float(msg.lon[:3])+float(msg.lon[3:])/60
		    #print latitude, longitude
		    FIRST_POS=True
		    (x_utm,y_utm,zone_number,zone_letter)=utm.from_latlon(latitude,longitude)
		    #map_queue.put([longitude,latitude,random.randint(0,2)])
		    map_queue.put([longitude,latitude])
		    Count=Count+1
		    #print utm.from_latlon(latitude, longitude)[0]
	
#SCRIVE I MESSAGGI PER LA TESTA (MESSAGGI DA INVIARE AGLI SCOOTER E MESSAGGI PER LA LOCALIZZAZIONE
#IMPLEMENTARE INVIO MESSAGGIO POSIZIONE TESTA WGS84
def telnet_write(): #implementare 
	global surface_queue, deliv_queue, latitude, longitude, Count
	while True:
		if Count>9:
		#Trasmissione posizione testa in WGS84
			msg='0'+';'+str(latitude)+';'+str(longitude) 
			IM=INSTANT_MSG("0","255","noack",len(msg),msg,True)
			print IM.message
			evologics.write_data(IM.message)
			Count=0
			time.sleep(2)
			#BISOGNA VEDERE I TEMPI DI ATTESA SE SONO CORRETTI IN ACQUA, IN ARIA LA SITUAZIONE E' LIMITE
			#PERCHE' IL DISPOSITIVO DOPO AVER INVIATO UN MESSAGGIO CON ACK RIMANE IN ATTESA PER UN TEMPO NON DEFINITO MENTRE
			#SENZA ACK PUO' INVIARE IN CONTINUAZIONE
		
		for i in range(0,trasponder_number):
			if Localization:
				IM=INSTANT_MSG("0",str(trasponder_address[i]),"ack",1,"-",True)
				print IM.message
				evologics.write_data(IM.message)
				now=time.time()
				expired_time=0;
				while expired_time<1 and deliv_queue.empty():
					expired_time=time.time()-now
					time.sleep(0.01)
				if not deliv_queue.empty():
					a=deliv_queue.get()
				print (1.5-expired_time)
				time.sleep(1.5-expired_time)
			
		if not surface_queue.empty():
			[modem, message]=surface_queue.get()
			if modem==15:
				modem='255'
			else:	
				modem=chr(modem+48)
			if message=='HEALS':#DA IMPLEMENTARE NELLA JETSON
				IM=INSTANT_MSG("0",modem,"noack",len(message),message,True)
				print IM.message
				evologics.write_data(IM.message)
				time.sleep(1)
			elif message=='HEAL':#DA IMPLEMENTARE NELLA JETSON
				IM=INSTANT_MSG("0",modem,"ack",len(message),message,True)
				print IM.message
				evologics.write_data(IM.message)
				now=time.time()
				expired_time=0;
				while expired_time<2 and deliv_queue.empty():
					expired_time=time.time()-now
					time.sleep(0.01)
				if not deliv_queue.empty():
					a=deliv_queue.get()
			elif message=='NOHEAL':#DA IMPLEMENTARE NELLA JETSON
				IM=INSTANT_MSG("0",modem,"noack",len(message),message,True)
				print IM.message
				evologics.write_data(IM.message)
				time.sleep(1)
			elif message=='POS':
				IM=INSTANT_MSG("0",modem,"ack",len(message),message,True)
				print IM.message
				evologics.write_data(IM.message)
				now=time.time()
				expired_time=0;
				while expired_time<2 and deliv_queue.empty():
					expired_time=time.time()-now
					time.sleep(0.01)
				if not deliv_queue.empty():
					a=deliv_queue.get()
			else:
				message='1;'+message
				IM=INSTANT_MSG("0",modem,"ack",len(message),message,True)
				print IM.message
				evologics.write_data(IM.message)
				now=time.time()
				expired_time=0;
				while expired_time<2 and deliv_queue.empty():
					expired_time=time.time()-now
					time.sleep(0.01)
				if not deliv_queue.empty():
					a=deliv_queue.get()

def telnet_client(): #Quello che leggo da telnet lo mando su UDP, 
	#RECVIM per ricezione messaggi da vari scooter
	#DELIVERDIM: Messaggi per posizione, Messaggi da sotto a sopra (attenzione rifare meccanismo Ack)
	serverAddressPort   = (address[0], int(sys.argv[2]))
	bufferSize          = 1024
	#Create a UDP socket at client side
	UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
	if debug==True:
		f_usbl = file("usbl"+str(l)+".txt", 'a')# millis angoli acc x_usbl y_usbl z_usbl depth x y z ax ay az
	while 1:
		data=evologics.read_data()
		if data:
			f_usbl.write(data)
			campi=evologics.parse_msg()
			print campi
			if campi[0]=="USBLLONG": #SE LO RICEVO Lo devo inviare la pos in wgs84 in superficie e L'ENU in profondita'
				#global x, y, z, roll, pitch, yaw, FIRST_POS_Scouter, pos_queue
				x=float(campi[4])
				y=float(campi[5])
				z=float(campi[6]) # Ho il profondimetro
				east=float(campi[7])
				north=float(campi[8])
				up=float(campi[9])				
				# Orientamento TESTA, non so se mi potrebbe servire
				roll=float(campi[10])
				pitch=float(campi[11])
				yaw=float(campi[12])
				rssi=campi[14]
				accuracy=campi[16]
				#Invio GPS su UDP
				(lat,lon)=utm.to_latlon(x_utm+east,y_utm+north,zone_number,zone_letter)
				message=DS_POS(time.time(),campi[3],lat,lon,campi[9])
				UDPClientSocket.sendto(message, serverAddressPort) 
				#Invio ENU a scooter
				msg='2'+';'+campi[7]+';'+campi[8]
				IM=INSTANT_MSG("0",campi[3],"noack",len(msg),msg,True)
				print IM.message
				evologics.write_data(IM.message)
			elif campi[0]=="USBLANGLES": #QUESTI DATI NON MI DOVREBBERO SERIVIRE quindi non faccio un cazzo
				roll=campi[8]
				pitch=campi[9]
				yaw=campi[10]
				rssi=campi[11]
				accuracy=campi[13]
			elif campi[0]=="RECVIM": #IL RECVIM PUo' essere solo un messaggio da uno scooter
				#QUI Puo' essere il messaggio della salute o una posizione o il messaggio altri messaggi
				#CAMBIARE
				wgs84=campi[10].split(';')
				print wgs84
				if wgs84[0]=='0':
					wg=wgs84[3].split('\r')
					message=DS_POS(campi[3],wgs84[1],wgs84[2],wg)
					UDPClientSocket.sendto(message, serverAddressPort) 
					#RISPOSTA AL COMANDO POS
				elif wgs84[0]=='1':
					surf_message=DS_MES(campi[3],wgs84[1])
					UDPClientSocket.sendto(surf_message, serverAddressPort) 
				elif wgs84[0]=='3':#AGGIUNGERE HEAL
					surf_message=DS_HEAL(campi[3],wgs84[1],wgs84[2],wgs84[3])
					UDPClientSocket.sendto(surf_message, serverAddressPort) 
					#print surf_message
			elif campi[0]=="DELIVEREDIM":#Devo gestire quello generato quando chiedo la posizione da quello del messaggio
				deliv_queue.put(campi[1])	
			elif campi[0]=="CANCELLEDIM":#Devo gestire quello generato quando chiedo la posizione da quello del messaggio 
				deliv_queue.put(campi[1])#Vorrei evitare di vederlo	
		#print data
		if not map_queue.empty():
			[lat,lon]= map_queue.get()
			message=DS_POS("0",lat,lon,"0")
			UDPClientSocket.sendto(message, serverAddressPort)  #STREAMMARE ANCHE LA POSIZIONE DELLA BOA CHE E' IN MAP_QUEUE

def handle_client_connection(client_socket):###########
	global TCPserverstate, mb,mb2##########
	request = client_socket.recv(1024)
	print ":".join("{:02x}".format(ord(c)) for c in request)#############
	[c,TCPserverstate.pointer,TCPserverstate.counter,TCPserverstate.dataLength, TCPserverstate.totalLength,TCPserverstate.typ , TCPserverstate.address,TCPserverstate.vendor,TCPserverstate.model,TCPserverstate.command]=executeStateMachine(request,TCPserverstate,0)
	if c>0 and executeCheckMessage(TCPserverstate,mb,genericList,genericListLength,specificList,specificListLength)==1 and TCPserverstate.address!=0xF:
		#ack="\0" * (ord(TCPserverstate.totalLength)+3)
		b="\0" * 2
		[s,ack]=createMessage(mb,TCPserverstate,b,0,0)###########
		#print ":".join("{:02x}".format(ord(c)) for c in ack)
		client_socket.send(ack)
		global trasponder_number, trasponder_address, surface_queue, Localization, Heal
		print ord(TCPserverstate.command)
		if (TCPserverstate.command=='\0'):
			print 'stop'
			Localization=False
		elif (TCPserverstate.command=='\1'):
			print 'start'			
			Localization=True
			trasponder_number=ord(request[8])
			del trasponder_address[:]
			for i in range(0,trasponder_number):
				trasponder_address.append(ord(request[9+i]))
		elif (TCPserverstate.command=='\3'):
			print 'heal'
			Heal=True
			surface_queue.put([15,'HEAL'])######
		elif (TCPserverstate.command=='\4'):	
			print 'noheal'
			surface_queue.put([15,'NOHEAL'])#########
			Heal=False
			
	elif c>0 and TCPserverstate.typ==4:########################NEW
		#ack="\0" * (ord(TCPserverstate.totalLength)+3)
		b="\0" * 2
		mb2.address=TCPserverstate.address;
		[s,ack]=createMessage(mb2,TCPserverstate,b,0,0)###########
		#print ":".join("{:02x}".format(ord(c)) for c in ack)
		client_socket.send(ack)
		if (TCPserverstate.command=='\2'):
			surface_queue.put([(TCPserverstate.address),request[9:9+ord(TCPserverstate.dataLength)-2]])
			#print request[9]
			#print request[10:10+ord(TCPserverstate.dataLength)-3]
		elif (TCPserverstate.command=='\5'):
			surface_queue.put([(TCPserverstate.address),'HEAL'])
			heal_queue.put(TCPserverstate.address)
		elif (TCPserverstate.command=='\6'):
			surface_queue.put([(TCPserverstate.address),'POS'])
			pos_queue.put(TCPserverstate.address)	
	client_socket.close()



def tcp_server(): #CAMBIARE SUL FINALE
	bind_ip = '0.0.0.0'
	bind_port = int(sys.argv[1])
	server_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	server_tcp.bind((bind_ip, bind_port))
	server_tcp.listen(5)  # max backlog of connections
	print 'Listening on {}:{}'.format(bind_ip, bind_port)
	tcp_stream=False
	if debug==True:
		f_tcp = file("tcp"+str(l)+".txt", 'a')# 
	
	while True:
		global address
		client_sock, address = server_tcp.accept()
		print 'Accepted connection from {}:{}'.format(address[0], address[1])
		global tcp_enabled
		tcp_enabled=False
		client_handler = threading.Thread(
	        target=handle_client_connection,
	        args=(client_sock,)  # without comma you'd get a... TypeError: handle_client_connection() argument after * must be a sequence, not _socketobject
		)
		client_handler.start()
		

def main():
	if len(sys.argv)==4:
		if sys.argv[1]=='debug':
			global debug
			debug=True
	if len(sys.argv)>2:
		tcp = threading.Thread(name='tcp_server', target=tcp_server)
		#udp = threading.Thread(name='udp_client', target=udp_client)
		tcp.daemon = True
		tcp.start()
		
		gps = threading.Thread(name='gps_udp', target=GPS_loop)
		#udp = threading.Thread(name='udp_client', target=udp_client)
		gps.daemon = True
		gps.start()
		
		while (trasponder_number==0 or not FIRST_POS):
			time.sleep(0.5)
		# telnet = threading.Thread(name='telnet', target=telnet_client)
		# telnet.daemon = True
		# telnet.start()
		telnet = threading.Thread(name='telnet_loop', target=telnet_write)
		telnet.daemon = True
		telnet.start()
		telnet_client()

	else:
		print "Few Arguments. Insert TCP, UDP"
	
if __name__== '__main__':main()

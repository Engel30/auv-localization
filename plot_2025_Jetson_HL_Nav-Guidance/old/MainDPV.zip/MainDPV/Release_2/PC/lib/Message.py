import utm
import datetime

def checksum(message):
	checksum=0
	for i in range(1,len(message)-1):
		checksum^=ord(message[i])
	if checksum >15:
		checksum=hex(checksum)[2:]
	else:
		checksum='0'+hex(checksum)[2:]
	return checksum
	
def ORA():
	# hh=now.hour
	# mm=now.minute
	# ss=now.second
	# if hh < 10:
		# HH='0'+str(hh)
	# else:
		# HH=str(hh)	
	# if mm < 10:
		# MM='0'+str(mm)
	# else:
		# MM=str(mm)	
	# if ss < 10:
		# SS='0'+str(ss)
	# else:
		# SS=str(ss)	  
	dateTime = datetime.now()
	ora = dateTime.strftime("%H%M%S.%f")	
	return ora
	
	
def DS_POS(addr,lat,lon,depth):
	#(lat,lon)=utm.to_latlon(xx,yy,zone_number,zone_letter)
	#now=datetime.datetime.now()
	ora=ORA()
	data=ora+',T,'+addr+','+str(lat)+',N,'+str(lon)+',E,'+depth+',M'
	message='#DS_POS,'+data+'*'
	chk=checksum(message)
	message+=chk
	#print message
	return message

	
def DS_HEAL(addr,glycemia,breath_rate,hr):
	ora=ORA()
	data=ora+',T,'+addr+','+str(glycemia)+',GL,'+str(breath_rate)+',BR,'+str(hr)+',HR'
	message="#DS_HEAL,"+data+"*"
	chk=checksum(message)
	message+=chk
	return message

def DS_DEC(dec):
	ora=ORA()
	msg=''
	for i in range(len(dec)):
		if dec[i][1]>0:
			msg+=','+str(dec[i][0])+',T'+str(i+1)+','+str(dec[i][1])+',DP'+str(i+1)
		else:
			msg+=','+str(dec[i][0])+',T'+str(i)+','+str(dec[i][1])+',DP'+str(i)
	data=ora+',T'+msg+',M'
	message="#DS_DEC,"+data+"*"
	chk=checksum(message)
	message+=chk
	return message
	
def DS_MES(addr,data):
	message="#DS_MES,"+addr+','+data+"*"
	chk=checksum(message)
	message+=chk
	return message


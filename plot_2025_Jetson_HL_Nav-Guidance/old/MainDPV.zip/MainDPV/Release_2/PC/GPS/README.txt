client legge la seriale gps e la manda su udp
server legge su udp la risposta di sinaps

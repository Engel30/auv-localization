import socket
import serial
import time

serverAddressPort   = ("127.0.0.1", 8881)
bufferSize          = 1024

PORT="/dev/ttyUSB0"
ser = serial.Serial(PORT, 9600,parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS,xonxoff=False, rtscts=False, dsrdtr=False)

# Create a UDP socket at client side
UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

def read_str(ser):
	GPS=""
	byte_letti=0
	bytesToRead = ser.inWaiting()
	if bytesToRead>0:
		GPS=str(ser.read(bytesToRead))
		byte_letti=bytesToRead
		while GPS[byte_letti-1]!='\n':
			time.sleep(0.020)
			bytesToRead = ser.inWaiting()
			if bytesToRead>0:
				GPS+=str(ser.read(bytesToRead))
				byte_letti+=bytesToRead
	return GPS,byte_letti
	

while (1):
	
	[GPS_string,n]=read_str(ser)
	strings=GPS_string.split('\r\n')
	#print n
	if n>0:
		for i in strings:
			if i[0:6]=='$GPGGA' or i[0:6]=='$GNGGA':
				msg = str.encode(i+'\n')
				UDPClientSocket.sendto(msg, serverAddressPort)
				print(msg)
	time.sleep(0.1)
	

/*
    Simple udp server
*/
#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <arpa/inet.h>
#include <sys/socket.h>
#include <iostream>
#include <cstdint>
#include <thread>
#include <fstream>
#include <iomanip>
#include <termios.h>
#include <unistd.h>
#include <dirent.h>
#include <libgen.h>
 
#define BUFLEN 512  //Max length of buffer
#define PORT 8881   //The port on which to listen for incoming 

using namespace std;
 
void die(char *s)
{
    perror(s);
    exit(1);
}

int count_files(){
	struct dirent *de;
	char path[PATH_MAX],di[PATH_MAX];
	ssize_t c=readlink("/proc/self/exe",path,PATH_MAX);
	path[c]=0;
	//cout<<path<<endl;
	DIR *dir = opendir(dirname(path));
	if (dir==NULL) 
	{
		cout<<"Failed to open dir\n";
		return -1;
	}
	int count=0;
	while (de=readdir(dir))
		count++;
	closedir(dir);	
	return count;	
}

 
int main(void)
{
	int j=count_files();
	string file_name="prova"+to_string(j)+".txt";
	
	
    struct sockaddr_in si_me, si_other;
    int s, i, recv_len;
    socklen_t slen = sizeof(si_other) ;
    char buf[BUFLEN];
    //create a UDP socket
    if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
        die("socket");
    }
     
    // zero out the structure
    memset((char *) &si_me, 0, sizeof(si_me));
     
    si_me.sin_family = AF_INET;
    si_me.sin_port = htons(PORT);
    si_me.sin_addr.s_addr = htonl(INADDR_ANY);
     
    //bind socket to port
    if( bind(s , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1)
    {
        die("bind");
    }
	ofstream myfile;
	    //keep listening for data
	    while(1)
	    {	        
	        printf("Waiting for data...");
	        fflush(stdout);
	        
	        //try to receive some data, this is a blocking call
	        if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, &slen)) == -1)
	        {
	            die("recvfrom()");
	        }
	         
	        //print details of the client/peer and the data received
	        printf("Received packet from %s:%d%d\n", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port),si_other.sin_family);
			myfile.open(file_name,ios::out | ios::app);
			if ( myfile.is_open()){
				for (int j=0;j<recv_len;j++){
					myfile<<buf[j];
					printf("%c",buf[j]);
				}
			}
			myfile.close();
	    }
	
	
    close(s);
    return 0;
} 

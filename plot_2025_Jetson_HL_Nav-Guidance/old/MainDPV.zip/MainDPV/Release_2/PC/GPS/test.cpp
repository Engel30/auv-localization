/*
    Simple udp server
*/
#include <iostream>
#include <string.h> 
#include <fstream>
#include <unistd.h>
#include <thread>
 
#define BUFLEN 512  //Max length of buffer
#define PORT 8882   //The port on which to listen for incoming 

using namespace std;

string file_name;
ofstream myfile2;
bool prova=false;


 
int main(void)
{
	file_name="prova.txt";
	LOOP:
    myfile2.open(file_name,ios::out| ios::app);
    if ( myfile2.is_open()){

			myfile2<<"vaffamculo\n";
		sleep(1);
		
	}
		myfile2.close();
		goto LOOP;
    return 0;
} 
